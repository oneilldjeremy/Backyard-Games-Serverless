
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'oneilldjeremy',
  applicationName: 'backyard-games',
  appUid: '77h804t6R7TfhgfZtS',
  orgUid: 'ba494553-24e0-45f4-a497-f400a2bdde29',
  deploymentUid: 'f4267a0d-621b-478e-b7ee-e65ce79b4a6c',
  serviceName: 'backyard-games',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.4.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'backyard-games-dev-GetUserGames', timeout: 6 };

try {
  const userHandler = require('./src/lambda/http/getUserGames.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}